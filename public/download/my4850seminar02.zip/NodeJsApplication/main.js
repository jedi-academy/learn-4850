// ACIT4850 - seminar 2 outcome

var http = require('http'), fs = require('fs'), xmldom = require('xmldom');
http.createServer(function (req, res) {
    data = fs.readFileSync('./data/order4.xml')
    parser = new xmldom.DOMParser();
    xmldoc = parser.parseFromString(data.toString(), 'text/xml');
    xmlroot = xmldoc.documentElement;
    res.writeHead(200, {'Content-Type': 'text/html'});
    heading = '<h1>Greasy Spoon Order for ' + xmlroot.getElementsByTagName('customer')[0] + '</h1>';
    res.write(heading);

    result = '';
    x = xmlroot.childNodes;
    for (i = 0; i < x.length; i++) {
        if (x[i].nodeName == 'burger') {
            result += showBurger(x[i]);
        }
    }
    res.write(result);

    res.end();


}).listen(8080);

function showBurger(burger) {
    which = burger.getElementsByTagName('patty')[0].getAttribute('type');
    result = '<h2>' + which + " burger</h2>";
    cheese = '';
    toppings = '';
    sauces = '';
    choices = burger.childNodes;
    for (cc = 0; cc < choices.length; cc++) {
        switch (choices[cc].nodeName) {
            case('cheeses'):
                cheese += choices[cc].getAttribute('top') + ' ' + choices[cc].getAttribute('bottom');
                continue;
            case('topping'):
                toppings += choices[cc].getAttribute('type') + ', ';
                continue;
            case('sauce'):
                sauces += choices[cc].getAttribute('type') + ', ';
                continue;
        }
    }
    result += '<p>' +
            'Cheeses: ' + cheese + '<br>' +
            'Toppings: ' + toppings + '<br>' +
            'Sauces: ' + sauces +
            '</p>';

    return result;
}