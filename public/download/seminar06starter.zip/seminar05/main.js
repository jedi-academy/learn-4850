// ACIT4850 - seminar 6 ...

var http = require('http'), fs = require('fs'), xmldom = require('xmldom');
http.createServer(function (req, res) {
    data = fs.readFileSync('./data/tasks.xml')

    var validator = require('xsd-schema-validator');
    validator.validateXML(data, 'data/tasks.xsd', function (err, result) {
        if (err) {
            console.log(result);
        }

        result.valid; // true
    });

    parser = new xmldom.DOMParser();
    xmldoc = parser.parseFromString(data.toString(), 'text/xml');
    xmlroot = xmldoc.documentElement;
    res.writeHead(200, {'Content-Type': 'text/html'});
    heading = '<h1>TO DO LIST</h1>';
    res.write(heading);

    result = '';
    x = xmlroot.childNodes;
    for (i = 0; i < x.length; i++) {
        if (x[i].nodeName == 'task') {
            result += showJob(x[i]);
        }
    }
    res.write(result);

    res.end();


}).listen(8080);

function showJob(work) {
    let jobid = work.getElementsByTagName('id')[0];
    let jobdesc = work.getElementsByTagName('job')[0];
    result = 'Job ' + jobid + ": " + jobdesc + '<br/>';
    return result;
}